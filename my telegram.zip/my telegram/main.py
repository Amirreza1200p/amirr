from telethon import TelegramClient, events
import os, json, re

# اطلاعات اکانت
api_id = 22469157
api_hash = "acfada75b11b221d6e7023a4de8f6803"
session_name = "my_session"

# کانال مقصد
target_channel = "@amiri12005"

# کانال‌های مبدا
source_channels = [
    "FO_RK",
    "akhbar1khatii",
    "NE_WG",
    "khabarfouri",
    "amiri12006"
]

# فایل ذخیره پیام‌های ارسال‌شده
sent_file = "sent.json"
if os.path.exists(sent_file):
    with open(sent_file, "r") as f:
        sent_ids = json.load(f)
else:
    sent_ids = []

# حذف ایموجی‌ها
def remove_emojis(text):
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # شکلک‌های معمولی
        "\U0001F300-\U0001F5FF"  # نمادها و پیکتوگرام‌ها
        "\U0001F680-\U0001F6FF"  # نمادهای حمل‌ونقل
        "\U0001F1E0-\U0001F1FF"  # پرچم‌ها
        "\U00002700-\U000027BF"
        "\U000024C2-\U0001F251"
        "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', text)

# پاکسازی متن: حذف @ + حذف ایموجی
def clean_text(text):
    if not text:
        return ""
    text = re.sub(r"@\w+", "", text)  # حذف کلمات @
    text = remove_emojis(text)        # حذف ایموجی‌ها
    return text.strip()

client = TelegramClient(session_name, api_id, api_hash)

@client.on(events.NewMessage(chats=source_channels))
async def handler(event):
    global sent_ids

    unique_id = f"{event.chat_id}_{event.id}"
    if unique_id in sent_ids:
        print("⚠ پیام تکراری رد شد")
        return

    raw_text = event.message.message or ""

    # اگر پست لینک داشت، کلاً رد میشه
    if re.search(r"http\S+|www\.\S+|t\.me", raw_text):
        print("⛔ پست حاوی لینک بود و ارسال نشد")
        return

    text = clean_text(raw_text)

    try:
        if event.message.media:
            await client.send_file(target_channel, event.message.media, caption=text if text else None)
        elif text:
            await client.send_message(target_channel, text)
        else:
            print("⚠ پست خالی بود و رد شد")
            return

        sent_ids.append(unique_id)
        with open(sent_file, "w") as f:
            json.dump(sent_ids, f)

        print(f"✅ ارسال شد: {text[:50]}")

    except Exception as e:
        print(f"❌ خطا در ارسال به کانال مقصد: {e}")

print("🔥 ربات روشن شد و منتظر پیام‌های جدید است...")
client.start()
client.run_until_disconnected()
